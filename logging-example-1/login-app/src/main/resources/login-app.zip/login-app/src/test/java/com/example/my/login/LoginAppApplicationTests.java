package com.example.my.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
