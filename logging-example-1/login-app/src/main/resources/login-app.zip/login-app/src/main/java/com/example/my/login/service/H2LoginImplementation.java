package com.example.my.login.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.service.entities.UserCredentialH2;
import com.example.my.login.service.repository.UserCredentialRepositoryH2;

//@Service("h2")
public class H2LoginImplementation implements LoginService {
	
	@Autowired
	private UserCredentialRepositoryH2 usrCredRepo;

	@Override
	public boolean checkLogin(LoginRequest request) {
		//Object o = usrCredRepo.findByUsernameAndPassword(request.getUsername(), request.getPassword());
		//return o==null?true:false;
		boolean result = false;
		UserCredentialH2 entity = usrCredRepo.findByUsername(request.getUsername());
		if(entity!=null && Arrays.equals(request.getPassword(), entity.getPassword())) {
			result = true;			
		}
		return result;
	}

}
