package com.example.my.login.service.entities;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.example.my.common.models.login.LoginRequest;

@Document
public class UserCredential {
	
	private String username;
	private char[] password;
	private Date createdOn;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public char[] getPassword() {
		return password;
	}

	public void setPassword(char[] password) {
		this.password = password;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public static UserCredential convert(LoginRequest input) {
		UserCredential instance = new UserCredential();
		instance.setUsername(input.getUsername());
		instance.setPassword(input.getPassword());
		instance.setCreatedOn(new Date());
		return instance;
	}
}
