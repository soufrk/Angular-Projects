package com.example.my.login.endpoints;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.my.common.api.login.UserCredentialApi;
import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.models.UserCredentialResponse;
import com.example.my.login.service.UserCredentialService;

@RestController
@RequestMapping("usercred")
public class UserCredentialController implements UserCredentialApi {
	
	@Autowired
	private UserCredentialService service;
	
	@Override
	public ResponseEntity<?> addUser(LoginRequest request) {
		return SimpleResponse.buildResponse(service.addUser(request));
	}
	
	@Override
	public ResponseEntity<?> getAllUsers(){
		List<UserCredentialResponse> listOfUsers = service.listAllUsers();
		return SimpleResponse.buildResponse(listOfUsers);
	}

}
