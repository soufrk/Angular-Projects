package com.example.my.login.service.repository;

import com.example.my.login.service.entities.UserCredentialH2;

//@Repository("h2Repo")
//public interface UserCredentialRepositoryH2 extends JpaRepository<UserCredentialH2, String>{
public interface UserCredentialRepositoryH2{
	
	UserCredentialH2 findByUsernameAndPassword(String username, char[]password);

	UserCredentialH2 findByUsername(String username);
}
