package com.example.my.login.service;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.models.UserCredentialResponse;
import com.example.my.login.service.entities.UserCredential;
import com.example.my.login.service.repository.UserCredentialRepository;
import com.mongodb.MongoWriteException;

@Service
public class UserCredentialManager implements UserCredentialService {
	
	@Autowired
	private UserCredentialRepository userCredRepo;

	@Override
	public boolean addUser(LoginRequest request) {
		boolean result = false;
		UserCredential savedEntity = null;
		try {
			savedEntity = userCredRepo.save(UserCredential.convert(request));			
		} catch(MongoWriteException m) {
			// As of now do nothing 
		}
		if(savedEntity != null) {
			result = true;			
		}
		return result;
	}

	@Override
	public List<UserCredentialResponse> listAllUsers() {
		List<UserCredentialResponse> resultList = new LinkedList<>();
		resultList = userCredRepo.findAll().stream()
			.map(u->new UserCredentialResponse(
					u.getUsername(), 
					u.getPassword().length>0?"*****":"", 
					u.getCreatedOn())
				)
			.collect(Collectors.toList());
		return resultList;
	}

}
