package com.example.my.login.service;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.models.UserCredentialResponse;
import com.example.my.login.service.entities.UserCredentialH2;
import com.example.my.login.service.repository.UserCredentialRepositoryH2;

//@Service
public class H2UserCredentialManager implements UserCredentialService {
	
	@Autowired
	private UserCredentialRepositoryH2 usrCredRepo;

	@Override
	public boolean addUser(LoginRequest request) {
		boolean response = false;
//		UserCredentialH2 savedEntity = usrCredRepo.save(UserCredentialH2.convert(request));
//		if(savedEntity != null) {
//			response = true;			
//		}
		return response;
	}

	@Override
	public List<UserCredentialResponse> listAllUsers() {
		List<UserCredentialResponse> resultList = new LinkedList<>();
//		resultList = usrCredRepo.findAll().stream()
//			.map(u->new UserCredentialResponse(
//					u.getUsername(), 
//					u.getPassword().length>0?"*****":"", 
//					u.getCreatedOn())
//				)
//			.collect(Collectors.toList());
		return resultList;
	}

}
