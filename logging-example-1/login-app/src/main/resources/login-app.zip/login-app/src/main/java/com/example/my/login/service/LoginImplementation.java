package com.example.my.login.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.service.entities.UserCredential;
import com.example.my.login.service.repository.UserCredentialRepository;

@Service
public class LoginImplementation implements LoginService {
	
	@Autowired
	UserCredentialRepository userCredRepo;

	@Override
	public boolean checkLogin(LoginRequest request) {
		boolean result = false;
		UserCredential entity = userCredRepo.findByUsername(request.getUsername());
		if(entity!=null && Arrays.equals(request.getPassword(), entity.getPassword())) {
			result = true;			
		}
		return result;
	}

}
