package com.example.my.login.service;

import com.example.my.common.models.login.LoginRequest;

public interface LoginService {

	boolean checkLogin(LoginRequest request);

}
