package com.example.my.login.service.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.my.login.service.entities.UserCredential;

@Repository
public interface UserCredentialRepository extends MongoRepository<UserCredential, String> {

	UserCredential findByUsername(String username);

}
