package com.example.my.login.service;

import java.util.List;

import com.example.my.common.models.login.LoginRequest;
import com.example.my.login.models.UserCredentialResponse;


public interface UserCredentialService {

	boolean addUser(LoginRequest request);

	List<UserCredentialResponse> listAllUsers();

}
